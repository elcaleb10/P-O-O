package gestionfutbol;


public class Jugador {
    private String nombre;
    private String posicion;
    private int numero;
    //Mapeo
    private EquipoJugador equipojugadores[];
}
