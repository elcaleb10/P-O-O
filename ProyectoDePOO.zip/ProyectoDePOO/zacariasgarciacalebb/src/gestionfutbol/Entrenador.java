package gestionfutbol;

public class Entrenador {
    private String nombre;
    private int aniosExperiencia;
    //Mapeo
    private Equipo equipos;
    
}
