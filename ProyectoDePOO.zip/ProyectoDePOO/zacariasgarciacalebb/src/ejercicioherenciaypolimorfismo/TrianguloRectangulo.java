/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioherenciaypolimorfismo;

/**
 *
 * @author messi
 */
public class TrianguloRectangulo implements Figura {

    private double base = 1;
    private double altura = 1;

    public TrianguloRectangulo() {
    }

    public TrianguloRectangulo(double base, double altura) {
        setBase(base);
        setAltura(altura);
//        if (base >= 1 && base <= 1000) {
//            setBase(base);
//        }
//        if (altura >= 1 && altura <= 1000) {
//            setAltura(altura);
//        }
    }

    public double getBase() {
        return base;
    }

    public void setBase(double base) {
        if (base >= 1 && base <= 1000) {
            this.base = base;
        }
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        if (altura >= 1 && altura <= 1000) {
            this.altura = altura;
        }
    }

    @Override
    public double calcularPerimetro() {
        double ladoFaltante = Math.sqrt(Math.pow(base, 2)
                + Math.pow(altura, 2));
        return base + altura + ladoFaltante;
    }

    @Override
    public double calcularArea() {
        return (base * altura) / 2;
    }

    @Override
    public String toString() {
        return "TrianguloRectangulo [base="
                + String.format("%.2f", base) + ", altura="
                + String.format("%.2f", altura) + "]";
    }

//    @Override
//    public String toString() {
//        DecimalFormat formateador = new DecimalFormat("0.00");
//        return "TrianguloRectangulo(" + formateador.format(base) + ","
//                + formateador.format(altura) + ")";
//    }

    public void redimensionar(double porcentaje) {
        if (porcentaje >= 0) {
            double nuevaBase = base * (1 + (porcentaje / 100));
            double nuevaAltura = altura * (1 + (porcentaje / 100));
            if (nuevaBase >= 1 && nuevaBase <= 1000 && nuevaAltura >= 1
                    && nuevaAltura <= 1000) {
                base = nuevaBase;
                altura = nuevaAltura;
                System.out.println("El triángulo rectángulo ha sido "
                        + "redimensionado al " + porcentaje + "%");
            } else {
                if (nuevaBase < 1 || nuevaAltura < 1) {
                    base = 1;
                    altura = 1;
                    System.out.println("El redimensionamiento no es posible. "
                            + "Se han asignado los valores mínimos de 1 y 1 "
                            + "respectivamente.");
                } else {
                    base = 1000;
                    altura = 1000;
                    System.out.println("El redimensionamiento no es posible. "
                            + "Se han asignado los valores máximos de 1000 y "
                            + "1000 respectivamente.");
                }
            }
        } else {
            System.out.println("El redimensionamiento no es posible con "
                    + "porcentajes negativos.");
        }
    }

}
