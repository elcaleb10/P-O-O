/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ejercicioherenciaypolimorfismo;

/**
 *
 * @author messi
 */
public interface Figura {
    public double calcularPerimetro();
    public double calcularArea();
    public void redimensionar(double porcentaje);
    
}
