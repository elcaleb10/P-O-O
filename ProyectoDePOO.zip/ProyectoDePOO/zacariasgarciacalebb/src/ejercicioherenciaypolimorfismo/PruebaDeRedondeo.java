/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioherenciaypolimorfismo;

import java.text.DecimalFormat;

/**
 *
 * @author LMC Alumno
 */
public class PruebaDeRedondeo {
    public static void main(String[] args) {
//        DecimalFormat formateador = new DecimalFormat("###, ###.##");
//        DecimalFormat formateador2 = new DecimalFormat("###, ###.00");
        DecimalFormat formateador = new DecimalFormat("0.00");
        double numero = 123456.7890;
        System.out.println(formateador.format(numero));
//        System.out.println(formateador2.format(numero));
//        System.out.println(formateador2.format(numero));
        
    }
}
