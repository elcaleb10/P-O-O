/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoaplha1.operaciones;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import proyectoaplha1.modelos.Usuario;

/**
 *
 * @author LMC Alumno
 */
public class DAOUsuario {
    public ArrayList<Usuario> leerUsuarios(){
        ArrayList<Usuario> listaUsuarios=new ArrayList<>();
        try{
            ArrayList<String> lineas=Utileria.leerArchivo("usuarios.txt");
            for(String linea:lineas){
                String[] partesLinea=linea.split("-,-");
                Usuario usuario=new Usuario();
                usuario.setNombre(partesLinea[0]);
                usuario.setApellidos(partesLinea[1]);
                usuario.setTipo(partesLinea[2]);
                usuario.setUsuario(partesLinea[3]);
                usuario.setContrasenia(partesLinea[4]);
                listaUsuarios.add(usuario);
            }
            return listaUsuarios;
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null,"No pudo cargar "
                    + "los usuarios");
            return null;
        }
    }
}
