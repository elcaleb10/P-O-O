/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoaplha1.operaciones;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author LMC Alumno
 */
public class Utileria {
    public static ArrayList<String> leerArchivo(String archivo) throws Exception{
        ArrayList<String> lineasArchivo = new ArrayList<>();
        BufferedReader lector = null;
        try {
            lector = new BufferedReader(
                    new FileReader(archivo));
            String linea = lector.readLine();
            while (linea != null) {
                lineasArchivo.add(linea);
                linea = lector.readLine();
            }
            
            return lineasArchivo;
            
        } catch (IOException ex) {
            throw new Exception("Datos no encontrados");
        } finally {
            //Intentar cerrar y liberar el archivo (confirmar el guardado)
            try {
                lector.close();
            } catch (Exception ex) {
            }
        }
    }
}
