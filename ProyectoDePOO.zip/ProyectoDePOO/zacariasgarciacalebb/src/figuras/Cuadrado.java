/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package figuras;

/**
 *
 * @author LMC Alumno
 */
public class Cuadrado extends Cuadrilatero {

    public Cuadrado(int a){
        setLadoA(a);
    }
    
    @Override
    public void setLadoB(double ladoB) {
        super.setLadoB(ladoB);
        super.setLadoA(ladoB);
    }

    @Override
    public void setLadoA(double ladoA) {
        super.setLadoA(ladoA); 
        super.setLadoB(ladoA); 
    } 
    
    @Override
    public double calcularArea() {
        return getLadoA()*getLadoA();
    }
}