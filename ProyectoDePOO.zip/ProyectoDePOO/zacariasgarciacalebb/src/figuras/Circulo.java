/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package figuras;

import java.util.Objects;

/**
 *
 * @author LMC Alumno
 */
public class Circulo extends Figura {

    private double radio;
    public Ubicacion centro = new Ubicacion();

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }

    @Override
    public double calcularArea() {
        return Math.PI * Math.pow(radio, 2);
    }

    @Override
    public double calcularPerimetro() {
        return Math.PI * 2 * radio;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Circulo other = (Circulo) obj;
        if (this.radio != other.radio) {
            return false;
        }
//        if(this.centro.getX() != other.centro.getX()){
//            return false;
//        }
//        if(this.centro.getY() != other.centro.getY()){
//            return false;
//        }
//        return true;    
//        //return Objects.equals(this.centro, other.centro);
        return this.centro.equals(other.centro);
    }

}
