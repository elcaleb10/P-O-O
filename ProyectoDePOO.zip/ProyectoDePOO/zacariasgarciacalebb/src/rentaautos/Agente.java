/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentaautos;

import java.util.Date;

/**
 *
 * @author paveg
 */
public class Agente {
    private String nombre;
    private String direccion;
    private String telefono;
    private String correo;
    private Date fechaContratacion;
    
    private Sucursal sucursal;
    private Renta[] rentas;
    
//    public double calcularComision(){
//        
//    }
    
}
