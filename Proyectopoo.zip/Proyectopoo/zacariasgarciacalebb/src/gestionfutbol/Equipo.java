package gestionfutbol;

public class Equipo {
    private String nombre;
    private String estado;
    //Mapeo
    private EquipoJugador equiposjuagadores[];
}
