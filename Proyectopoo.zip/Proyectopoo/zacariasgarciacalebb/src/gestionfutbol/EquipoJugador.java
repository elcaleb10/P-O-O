package gestionfutbol;

import java.util.Date;

public class EquipoJugador {
    private Date fechaIngreso;
    //mapeo
    private Equipo equipos;
    private Jugador jugadores;
}
