package gestionfutbol;

import java.util.Date;

public class Partido {
    private Date fecha;
    private int golesLocal;
    private int golesVisitante;
    //Mspeo
    public Equipo local;
    public Equipo visitante;
}
