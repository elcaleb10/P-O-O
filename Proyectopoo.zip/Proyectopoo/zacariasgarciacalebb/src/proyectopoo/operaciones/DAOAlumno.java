/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoo.operaciones;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import proyectopoo.modelos.Alumno;

/**
 *
 * @author messi
 */
public class DAOAlumno {

    public ArrayList<Alumno> leerAlumnos() {
        ArrayList<Alumno> listaAlumnos = new ArrayList<>();
        try {
            ArrayList<String> lineas = Utileria.leerArchivo("alumnos.txt");
            for (String linea : lineas) {
                String[] partesLinea = linea.split("-,-");
                Alumno alumno = new Alumno();
                alumno.setNombre(partesLinea[0]);
                alumno.setApellidos(partesLinea[1]);
                alumno.setCarrera(partesLinea[2]);
                alumno.setNoControl(partesLinea[3]);
                alumno.setFechaIngreso(partesLinea[4]);
                
                listaAlumnos.add(alumno);
            }
            return listaAlumnos;
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "No pudo cargar "
                    + "los alumnos");
            return null;
        }
    }
    
    public boolean agregar(Alumno alumno){
        return Utileria.agregarLinea(alumno.toString(), 
                "alumnos.txt");
    }
    
    public Alumno buscar(String alumno){
        ArrayList<Alumno> alumnosExistentes=leerAlumnos();
        
        Alumno alumnoBuscado=new Alumno();
        alumnoBuscado.setNoControl(alumno);
        
        int posicion=alumnosExistentes.indexOf(alumnoBuscado);
        if(posicion>=0){
            return alumnosExistentes.get(posicion);
        }else{
            return null;
        }
//        for (int i = 0; i < alumnosExistentes.size(); i++) {
//                if(alumnosExistentes.get(i).getNoControl().equals(alumno)){
//                    return alumnosExistentes.get(i);
//                }
//        }
//        return null;
    }
    
    public boolean editar(Alumno alumno){
        //Cargar todos los usuarios
        ArrayList<Alumno> alumnosExistentes=leerAlumnos();
        //Buscar cual usuario voy a modificar 
        int posicion=alumnosExistentes.indexOf(alumno);
        if(posicion>=0){
            //Reemplazar el usuario viejo en la lista por el nuevo
            alumnosExistentes.set(posicion, alumno);
            
            //Vaciar esa lista en archivo
            return Utileria.reescribirArchivo(alumnosExistentes, 
                    "alumnos.txt");
        }else{
            return false;
        }
    }
    
    public boolean eliminar(String alumno){
        //Cargar todos los usuarios
        ArrayList<Alumno> alumnosExistentes=leerAlumnos();
        //Buscar cual usuario voy a eliminar
        Alumno alumnoABorrar=new Alumno();
        alumnoABorrar.setNoControl(alumno);
        if(alumnosExistentes.remove(alumnoABorrar)){
            //reescribir el archivo con la lista sin el usuario que borré
            return Utileria.reescribirArchivo(alumnosExistentes, 
            "alumnos.txt");
        }else{
            return false;
        }
        
//        for (int i = 0; i < usuariosExistentes.size(); i++) {
//                if(usuariosExistentes.get(i).getUsuario().equals(usuario)){
//                    usuariosExistentes.remove(i);
//                    //reescribir el archivo con la lista sin el usuario que borré
//                    return Utileria.reescribirArchivo(usuariosExistentes, 
//                    "usuarios.txt");
//                }
//        }
//      return false;
        
    }
    
}
