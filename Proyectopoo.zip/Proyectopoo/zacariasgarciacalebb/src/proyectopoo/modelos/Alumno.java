/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoo.modelos;

import java.util.Date;
import java.util.Objects;

public class Alumno {
    private String nombre;
    private String apellidos;
    private String carrera;
    private String noControl;
    private String fechaIngreso;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public String getNoControl() {
        return noControl;
    }

    public void setNoControl(String noControl) {
        this.noControl = noControl;
    }

    public String getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(String fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Alumno other = (Alumno) obj;
        return Objects.equals(noControl, other.noControl);
    }


    @Override
    public String toString() {
        return nombre + "-,-" + apellidos + "-,-" + carrera + "-,-" +
                noControl + "-,-" + fechaIngreso + "\n";
    }

    public Object[] toArray() {
        Object[] arreglo=new Object[4];
        arreglo[0]=noControl;
        arreglo[1]=nombre;
        arreglo[2]=apellidos;
        arreglo[3]=carrera;
        return arreglo; 
//        return new Object[]{noControl, nombre, apellidos, carrera};
    }
}
