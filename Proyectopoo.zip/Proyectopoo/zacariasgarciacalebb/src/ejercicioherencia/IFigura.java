/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ejercicioherencia;

/**
 *
 * @author LMC Alumno
 */
public interface IFigura {
    //Los atributos en interfaces siempre son constantes
    public String color="Rojo";
    
    public double calcularArea();
    public double calcularPerimetro();
    public void ejemplo();
}
