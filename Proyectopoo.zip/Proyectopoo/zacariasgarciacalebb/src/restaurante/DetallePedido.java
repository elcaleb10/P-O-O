package restaurante;

public class DetallePedido {
    private int unidades;
    private double subtotal;
    //Mapeo
    private Pedido pedidos;
    private Platillo platillos;
}
