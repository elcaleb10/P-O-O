package restaurante;

public class Platillo {
    private int numero;
    private String nombre;
    private String descripcion;
    private double preccio;
    //Mapeo
    private DetallePedido detallesPedidos[];
}
