package restaurante;

public class Cliente {
    private int numero;
    private String nombre;
    private String direccion;
    private String telefono;
    //Mapeo
    private Pedido pedidos[];
}
