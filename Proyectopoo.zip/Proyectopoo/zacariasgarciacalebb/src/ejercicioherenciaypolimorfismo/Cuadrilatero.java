/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioherenciaypolimorfismo;

import java.text.DecimalFormat;

/**
 *
 * @author messi
 */
public class Cuadrilatero implements Figura {

    private double lado1 = 1;
    private double lado2 = 2;

    public Cuadrilatero() {
    }

    public Cuadrilatero(double lado1, double lado2) {
        setLado1(lado1);
        setLado2(lado2);
//        if (lado1 >= 1 && lado1 <= 1000) {
//            setLado1(lado1);
//        } else {
//            System.out.println("Error: El lado1 debe estar entre 1 y 1000."
//                    + "Se usará el valor predeterminado de uno.");
//        }
//        if (lado2 >= 1 && lado2 <= 1000) {
//            setLado2(lado2);
//        } else {
//            System.out.println("Error: El lado2 debe estar entre 1 y 1000. "
//                    + "Se usará el valor predeterminado de uno.");
//        }
    }

    public double getLado1() {
        return lado1;
    }

    public void setLado1(double lado1) {
        if (lado1 >= 1 && lado1 <= 1000) {
            this.lado1 = lado1;
        } else {
            System.out.println("Error: El lado1 debe estar entre 1 y 1000. "
                    + "Se usará el valor predeterminado de uno.");
        }
    }

    public double getLado2() {
        return lado2;
    }

    public void setLado2(double lado2) {
        if (lado2 >= 1 && lado2 <= 1000) {
            this.lado2 = lado2;
        } else {
            System.out.println("Error: El lado2 debe estar entre 1 y 1000. "
                    + "Se usará el valor predeterminado de uno.");
        }
    }

    @Override
    public double calcularPerimetro() {
        return 2 * (lado1 + lado2);
    }

    @Override
    public double calcularArea() {
        return lado1 * lado2;
    }

//    @Override
//    public String toString() {
//        return "Cuadrilatero [lado1=" + String.format("%.2f", lado1)
//                + ", lado2=" + String.format("%.2f", lado2) + "]";
//    }
    
    @Override
    public String toString() {
        DecimalFormat formateador=new DecimalFormat("0.00");
        if(lado1==lado2){
            return "Cuadrado(" + formateador.format(lado1) + ")";
        }else{
            return "Rectangulo(" + formateador.format(lado1) + "," 
                + formateador.format(lado2) + ")";
        }
    }
    

    public void redimensionar(double porcentaje) {
        if (porcentaje >= 0) {
            double nuevaBase = lado1 * (1 + (porcentaje / 100));
            double nuevaAltura = lado2 * (1 + (porcentaje / 100));
            if (nuevaBase >= 1 && nuevaBase <= 1000 && nuevaAltura >= 1
                    && nuevaAltura <= 1000) {
                lado1 = nuevaBase;
                lado2 = nuevaAltura;
                System.out.println("El Cuadrilatero ha sido "
                        + "redimensionado al " + porcentaje + "%");
            } else {
                if (nuevaBase < 1 || nuevaAltura < 1) {
                    lado1 = 1;
                    lado2 = 1;
                    System.out.println("El redimensionamiento no es posible. "
                            + "Se han asignado los valores mínimos de 1 y 1 "
                            + "respectivamente.");
                } else {
                    lado1 = 1000;
                    lado2 = 1000;
                    System.out.println("El redimensionamiento no es posible. "
                            + "Se han asignado los valores máximos de 1000 y "
                            + "1000 respectivamente.");
                }
            }
        } else {
            System.out.println("El redimensionamiento no es posible con "
                    + "porcentajes negativos.");
        }
    }

}
