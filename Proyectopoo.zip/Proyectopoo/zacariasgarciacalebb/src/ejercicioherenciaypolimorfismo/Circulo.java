/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioherenciaypolimorfismo;

/**
 *
 * @author messi
 */
public class Circulo implements Figura {

    private double radio = 1;

    public Circulo() {
    }

    public Circulo(double radio) {
        setRadio(radio);
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        if (radio >= 1 && radio <= 1000) {
            this.radio = radio;
        } else {
            System.out.println("El radio debe estar entre 1 y 1000. "
                    + "Se usará el valor predeterminado de uno.");
        }
    }

    @Override
    public double calcularPerimetro() {
        return 2 * Math.PI * radio;
    }

    @Override
    public double calcularArea() {
        return Math.PI * Math.pow(radio, 2);
    }

    public void redimensionar(double porcentaje) {
        if (porcentaje >= 0) {
            double nuevoRadio = radio * (porcentaje / 100);
            if (nuevoRadio >= 1 && nuevoRadio <= 1000) {
                radio = nuevoRadio;
                System.out.println("El círculo ha sido redimensionado al " + 
                        porcentaje + "%");
            } else {
                if (nuevoRadio < 1) {
                    radio = 1;
                    System.out.println("El redimensionamiento no es posible. "
                            + "Se ha asignado el valor mínimo de 1.");
                } else {
                    radio = 1000;
                    System.out.println("El redimensionamiento no es posible. "
                            + "Se ha asignado el valor máximo de 1000.");
                }
            }
        } else {
            System.out.println("El redimensionamiento no es posible con "
                    + "porcentajes negativos.");
        }
    }

    @Override
    public String toString() {
        return "Circulo [radio=" + String.format("%.2f", radio) + "]";
    }
    
//    @Override
//    public String toString() {
//        DecimalFormat formateador=new DecimalFormat("0.00");
//        return "Circulo(" + formateador.format(radio) + ")";
//    }

}
