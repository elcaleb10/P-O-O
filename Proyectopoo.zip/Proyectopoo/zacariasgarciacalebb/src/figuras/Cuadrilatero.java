/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package figuras;

import java.util.ArrayList;

/**
 *
 * @author LMC Alumno
 */
public abstract class Cuadrilatero extends Figura {

    double ladoA;
    double ladoB;
    public ArrayList<Ubicacion> vertices = new ArrayList<>();

    public Cuadrilatero() {
    }

    public Cuadrilatero(int a, int b) {
        setLadoA(a);
        setLadoB(b);
    }

    public double getLadoA() {
        return ladoA;
    }

    public void setLadoA(double ladoA) {
        this.ladoA = ladoA;
    }

    public double getLadoB() {
        return ladoB;
    }

    public void setLadoB(double ladoB) {
        this.ladoB = ladoB;
    }

//
//    @Override
//    public abstract double calcularArea();
    @Override
    public double calcularPerimetro() {
        return 2 * ladoA + 2 * ladoB;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj.getClass() != this.getClass()) {
            return false;
        }
        Cuadrilatero otro = (Cuadrilatero) obj;

        if (this.getLadoA() != otro.getLadoA()) {
            return false;
        }
        if (this.getLadoB() != otro.getLadoB()) {
            return false;
        }
        //Verificar cada vértice
        //VII
        if (!this.vertices.get(0).equals(otro.vertices.get(0))) {
            return false;
        }
        //VSI
        if (!this.vertices.get(1).equals(otro.vertices.get(1))) {
            return false;
        }
        //VSD
        if (!this.vertices.get(2).equals(otro.vertices.get(2))) {
            return false;
        }
        //VID
        if (!this.vertices.get(3).equals(otro.vertices.get(3))) {
            return false;
        }
        return true;
    }
}
