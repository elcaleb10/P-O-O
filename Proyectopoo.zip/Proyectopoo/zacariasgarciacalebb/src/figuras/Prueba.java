/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package figuras;

/**
 *
 * @author LMC Alumno
 */
public class Prueba {
    public static void main(String[] args) {
        //No se puede crear figuras sin una forma concreta
//        Figura f = new Figura();
//        Cuadrilatero c = new Cuadrilatero;
            
//        Circulo c1 = new Circulo();
//        c1.setRadio(0.5);
//        c1.centro = new Ubicacion(2,9);
//        
//        Circulo c2= new Circulo();
//        c2.setRadio(0.5);
//        c2.centro.setX(2);
//        c2.centro.setY(7);
//        
//        Circulo c3 = new Circulo();
//        c3.setRadio(0.5);
        
        Cuadrado cu1 = new Cuadrado(5);
        cu1.vertices.add(new Ubicacion());
        cu1.vertices.add(new Ubicacion(0,5));
        cu1.vertices.add(new Ubicacion(5,5));
        cu1.vertices.add(new Ubicacion(5,0));
        
        Cuadrado cu2 = new Cuadrado(10);
        cu2.vertices.add(new Ubicacion());
        cu2.vertices.add(new Ubicacion(0,10));
        cu2.vertices.add(new Ubicacion(10,10));
        cu2.vertices.add(new Ubicacion(10,0));
        
        Cuadrado cu3 = new Cuadrado(10);
        cu3.vertices.add(new Ubicacion());
        cu3.vertices.add(new Ubicacion(0,10));
        cu3.vertices.add(new Ubicacion(10,10));
        cu3.vertices.add(new Ubicacion(10,0));
        
        System.out.println(cu1.equals(cu2));
        System.out.println(cu2.equals(cu3));
        
    }
}
