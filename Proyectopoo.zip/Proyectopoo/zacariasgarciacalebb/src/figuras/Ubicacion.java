/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package figuras;

/**
 *
 * @author LMC Alumno
 */
public class Ubicacion {
    private int x;
    private int y;

    public Ubicacion() {}
    
    public Ubicacion(int x, int y) {
        this.x = x;
        this.y = y;
    }
    
    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
    
    public boolean equals(Object obj){
        if(obj == null){
            return false;
        }
        
        if(obj.getClass() != this.getClass()){
            return false;
        }
        
        Ubicacion otraUbicacion = (Ubicacion) obj;
        if(this.getX() == otraUbicacion.getX() && this.getY() ==
                otraUbicacion.getY()){
            return true;
        }else{
            return false;
        }
        //return this.getY() == otraUbicacion.getY();
        
        
        
    }
    
}
