/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package polimorfismo;

import java.util.Objects;

/**
 *
 * @author messi
 */
public class Vehiculo {
    private String matricula;
    private String marca;
    private String modelo;


    public Vehiculo(String matricula, String marca, String modelo) {
        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
    }

    
    
    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        marca = marca.trim();
        if (marca.length() >= 2 && marca.length() <= 50) {
            this.marca = marca;
        } else {
            System.out.println("El nombre de la marca es incorrecta(debe de "
                    + "ser de minimo 2 caracteres a maximo 50)");
        }
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        modelo = modelo.trim();
        if (modelo.length() >= 1 && modelo.length() <= 20) {
            this.modelo = modelo;
        } else {
            System.out.println("El modelo es incorrecto(deben ser de minimo un"
                    + " caracter a 20)");
        }
    }

    @Override
    public String toString() {
        return "Matricula: " + matricula + "\nMarca: " + marca + "\nModelo: " + 
                modelo;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Vehiculo other = (Vehiculo) obj;
        if (!Objects.equals(this.matricula, other.matricula)) {
            return false;
        }
        if (!Objects.equals(this.marca, other.marca)) {
            return false;
        }
        return Objects.equals(this.modelo, other.modelo);
    }
    
    
    
}
