/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package polimorfismo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author messi
 */
public class Prueba {
    public static void main(String[] args) {
        List <Vehiculo> vehiculos = new ArrayList<>();
        
        Vehiculo miVehiculo1 = new Vehiculo("GHJ8", "Nissan",
                "GTR");
        vehiculos.add(miVehiculo1);
        
        Vehiculo miVehiculo2 = new VehiculoTurismo(4,
                "ZMV721", "Pontiac", "G7");
        vehiculos.add(miVehiculo2);
        
        Vehiculo miVehiculo3 = new VehiculoDeportivo(500,
                "GNJ987", "Chevrolet", "Suburban");
        vehiculos.add(miVehiculo3);
        
        Vehiculo miVehiculo4 = new VehiculoFurgoneta(2000, "J8",
                "Toyota", "J9");
        vehiculos.add(miVehiculo4);
        
        
        for(Vehiculo vehiculo : vehiculos){
            System.out.println("------------------------");
            if(vehiculo instanceof VehiculoTurismo){
                System.out.println("Vehiculo de Turismo");
            } else if(vehiculo instanceof VehiculoDeportivo){
                System.out.println("Vehiculo Deportivo");
            } else if(vehiculo instanceof VehiculoFurgoneta){
                System.out.println("Vehiculo Furgoneta");
            }else{
                System.out.println("Vehiculo");
            }
            System.out.println(vehiculo.toString());
        }
        
    }
}
