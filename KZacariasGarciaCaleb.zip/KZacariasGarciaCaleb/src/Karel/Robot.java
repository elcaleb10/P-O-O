/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Karel;

/**
 *
 * @author LMC Alumno
 */
public class Robot {
    //Atributos
    private String nombre;
    private char direccion;
    
    //metodos
    public Robot(){
        
    }
    
    
    
}
