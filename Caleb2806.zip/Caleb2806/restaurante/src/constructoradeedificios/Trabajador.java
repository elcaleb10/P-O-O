/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package constructoradeedificios;

/**
 *
 * @author paveg
 */
public class Trabajador {
    //Atributos
    private String nombre;
    private String cedula;
    private double pagoPorHora;
    //Atributos derivados del mapeo
    private Oficio oficio;
    private Contrato[] contratos;
    
}
