package restaurante;

public class Empleado {
    private int numero;
    private String nombre;
    private String direccion;
    private String telefono;
    private String poblacion;
    //Mapeo
    
}
