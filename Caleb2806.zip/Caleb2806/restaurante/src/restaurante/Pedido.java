package restaurante;

import java.time.LocalDate;

public class Pedido {
    private LocalDate fechaRegistro;
    private double totalApagar;
    public double calcularTotal(){
        return 0;
    }
    public double calcularTotalDePropina(){
        return 0;
    }
    //Mapeo
    private Cliente clientes;
    private Empleado empleados;
    private DetallePedido detallesPedidos[];
    
}
